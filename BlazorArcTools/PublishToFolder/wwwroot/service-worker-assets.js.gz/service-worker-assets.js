self.assetsManifest = {
  "version": "udOvAwcu",
  "assets": [
    {
      "hash": "sha256-sx3VMz8TwZ4ngQ4KxlYI6lgpRh+h+L9t3eAg7NDg2eg=",
      "url": "BlazorArcTools.styles.css"
    },
    {
      "hash": "sha256-6BiG+6jgfbbgCrod+DH4Uvc1VVhXslH7y9AxeSTB8wc=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-62UC3VfSQyaGpPUm7iSjBYuQ1xD31WdRYY20NQ1K+Vs=",
      "url": "_framework/dotnet.native.d2w7colv7e.wasm"
    },
    {
      "hash": "sha256-ddUN4+taa/Qv7Mr8mLpunJO+0Xw3ViOqBvedhe57/hA=",
      "url": "_framework/dotnet.native.l4ptthxatg.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-q+M9KuYS0d90n+FAp0ubLu5bUAbMB0HDoOmfaMgZu0E=",
      "url": "index.html"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-bEhcaQ1uxbyn78cfQuxZcltdrw/3H0Hx1YH3E9lG95A=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-WCEwe+1ubOgpJup7eH32eZdC4WSd4xs+eJzxiCIia0o=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-ro16XJXp+bujvTs6OfK7qxeX4aBXTi7aDzNl4d4AMC8=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-bZhAZd2EthaQrFjfDoaJaiFdmZCbE8KC0pUeo4bwtAM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-nBO8sPs4CKCXlgYSwHFOvYF2OBVhZmeydhRrFN5IWnI=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-Wq3oOO+D3iYDouxfof3bE+gK7a5XUW5uurLuEPV/ASU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-zptDqsjq2MY6APS1q48LuwR0TgCqGBQvaOTmLox3qWo=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-MHTdQNCi1f3D9uiUeFmYmODeLsG0cs2pS1d+bFVKQyc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-I0uowFnHtg4QBE+0ySXd/loa0dLar2d3C3QfjbfYEq0=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-v29HTA1N9JcsyhBS9fd0FlDC7nwmbSlyiWgBBgjNcRk=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
